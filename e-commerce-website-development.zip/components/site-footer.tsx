import Link from 'next/link'
import { NewsletterForm } from './newsletter-form'
import { SocialIcons } from './social-icons'

const POLICY_LINKS = [
  { href: '/policies/refund-policy', label: 'REFUND POLICY' },
  { href: '/policies/privacy-policy', label: 'PRIVACY POLICY' },
  { href: '/policies/terms-of-service', label: 'TERMS OF SERVICE' },
  { href: '/policies/shipping-policy', label: 'SHIPPING POLICY' },
  { href: '/contact', label: 'CONTACT INFORMATION' },
]

const PAYMENTS = [
  { label: 'bKash', className: 'bg-[#e2136e] text-white' },
  { label: 'Nagad', className: 'bg-[#f6921e] text-white' },
  { label: 'VISA', className: 'bg-[#1a1fb5] text-white italic' },
  { label: 'Mastercard', className: 'bg-neutral-900 text-white' },
  { label: 'AMEX', className: 'bg-[#1f72cd] text-white' },
  { label: 'Cash on Delivery', className: 'border border-black text-black' },
]

export function SiteFooter() {
  return (
    <footer className="mt-24 px-6 pb-10">
      <section className="mx-auto max-w-xl text-center">
        <h2 className="text-balance text-4xl uppercase leading-tight md:text-5xl">
          {"If you missed out don't worry..."}
        </h2>
        <p className="mt-6 text-pretty text-lg leading-relaxed">
          {"We've got lots to come very soon, join the email list to receive discounts, updates, and early access."}
        </p>
        <NewsletterForm />
      </section>

      <nav aria-label="Policies" className="mt-28 flex flex-col items-center gap-3">
        {POLICY_LINKS.map((link) => (
          <Link key={link.href} href={link.href} className="text-2xl tracking-wide hover:opacity-60 md:text-3xl">
            {link.label}
          </Link>
        ))}
      </nav>

      <SocialIcons />

      <ul aria-label="Payment methods" className="mx-auto mt-12 flex max-w-md flex-wrap justify-center gap-3">
        {PAYMENTS.map((p) => (
          <li
            key={p.label}
            className={`flex h-9 items-center rounded px-3 text-xs font-bold tracking-tight ${p.className}`}
          >
            {p.label}
          </li>
        ))}
      </ul>

      <p className="mt-12 text-center text-base">
        {'© '}
        {new Date().getFullYear()}, SECTORLOCKER
      </p>
    </footer>
  )
}
