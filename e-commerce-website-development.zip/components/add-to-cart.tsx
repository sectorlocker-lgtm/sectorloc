'use client'

import { useState } from 'react'
import Link from 'next/link'
import type { Size } from '@/lib/types'
import { useCart } from './cart-provider'

type Props = {
  product: { id: string; slug: string; name: string; price: number; image: string; sizes: Size[] }
}

export function AddToCart({ product }: Props) {
  const firstAvailable = product.sizes.find((s) => s.available)?.label ?? null
  const [size, setSize] = useState<string | null>(firstAvailable)
  const [added, setAdded] = useState(false)
  const [showGuide, setShowGuide] = useState(false)
  const { addItem } = useCart()

  const handleAdd = () => {
    if (!size) return
    addItem({ productId: product.id, slug: product.slug, name: product.name, price: product.price, image: product.image, size })
    setAdded(true)
    setTimeout(() => setAdded(false), 1800)
  }

  return (
    <div className="mt-10">
      <fieldset>
        <legend className="text-lg">
          Size: <span className="lowercase">{size ?? 'sold out'}</span>
        </legend>
        <div className="mt-4 flex flex-wrap gap-4">
          {product.sizes.map((s) => {
            const selected = s.label === size
            return (
              <button
                key={s.label}
                type="button"
                disabled={!s.available}
                aria-pressed={selected}
                onClick={() => setSize(s.label)}
                className={`border-2 px-8 py-4 text-lg tracking-wide transition-colors ${
                  selected
                    ? 'border-black bg-black text-white'
                    : s.available
                      ? 'border-neutral-300 bg-white hover:border-black'
                      : 'cursor-not-allowed border-neutral-200 bg-[linear-gradient(to_top_right,transparent_calc(50%-1px),#d4d4d4,transparent_calc(50%+1px))] text-neutral-400'
                }`}
              >
                {s.label}
                {!s.available && <span className="sr-only"> (sold out)</span>}
              </button>
            )
          })}
        </div>
      </fieldset>

      <button
        type="button"
        onClick={() => setShowGuide((v) => !v)}
        aria-expanded={showGuide}
        className="mt-8 border-b border-black pb-1 text-lg"
      >
        What size am I?
      </button>
      {showGuide && (
        <table className="mt-4 w-full text-left text-sm">
          <thead>
            <tr className="border-b border-neutral-200">
              <th className="py-2 font-normal text-neutral-500">Size</th>
              <th className="py-2 font-normal text-neutral-500">Chest (in)</th>
              <th className="py-2 font-normal text-neutral-500">Length (in)</th>
            </tr>
          </thead>
          <tbody>
            {[
              ['X-SMALL', '17', '21'],
              ['SMALL', '18', '22'],
              ['MEDIUM', '19', '23'],
              ['LARGE', '20', '24'],
              ['X-LARGE', '21', '25'],
            ].map(([s, c, l]) => (
              <tr key={s} className="border-b border-neutral-100">
                <td className="py-2">{s}</td>
                <td className="py-2">{c}</td>
                <td className="py-2">{l}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {size ? (
        <Link
          href={`/checkout?product=${encodeURIComponent(product.slug)}&size=${encodeURIComponent(size)}`}
          className="mt-10 block w-full bg-black py-5 text-center text-lg tracking-widest text-white transition-opacity hover:opacity-85"
        >
          PURCHASE
        </Link>
      ) : (
        <button
          type="button"
          disabled
          className="mt-10 w-full cursor-not-allowed bg-neutral-300 py-5 text-lg tracking-widest text-white"
        >
          SOLD OUT
        </button>
      )}
      {size && (
        <button
          type="button"
          onClick={handleAdd}
          className="mt-3 w-full border-2 border-black bg-white py-4 text-lg tracking-widest transition-colors hover:bg-neutral-50"
        >
          {added ? 'ADDED TO CART' : 'ADD TO CART'}
        </button>
      )}
      {added && (
        <p role="status" className="mt-3 text-center">
          <Link href="/cart" className="underline underline-offset-4">
            View cart
          </Link>
        </p>
      )}
    </div>
  )
}
