'use client'

import Image from 'next/image'
import Link from 'next/link'
import { formatPrice } from '@/lib/format'
import { useCart } from './cart-provider'

export function CartView() {
  const { items, subtotal, setQuantity, removeItem } = useCart()

  if (items.length === 0) {
    return (
      <section className="mx-auto max-w-xl px-6 pt-16 text-center">
        <h1 className="text-4xl uppercase">Your cart is empty</h1>
        <Link href="/catalog" className="mt-10 inline-block bg-black px-10 py-4 tracking-widest text-white">
          CONTINUE SHOPPING
        </Link>
      </section>
    )
  }

  return (
    <section className="mx-auto max-w-3xl px-6 pt-10">
      <h1 className="text-center text-4xl uppercase">Cart</h1>
      <ul className="mt-10 divide-y divide-neutral-200 border-y border-neutral-200">
        {items.map((item) => (
          <li key={item.key} className="flex gap-4 py-6">
            <Link href={`/products/${item.slug}`} className="relative size-24 shrink-0">
              <Image src={item.image || '/placeholder.svg'} alt={item.name} fill sizes="96px" className="object-contain" />
            </Link>
            <div className="flex flex-1 flex-col gap-2">
              <div className="flex justify-between gap-4">
                <p className="uppercase">{item.name}</p>
                <p className="shrink-0">{formatPrice(item.price * item.quantity, false)}</p>
              </div>
              <p className="text-sm text-neutral-500">Size: {item.size}</p>
              <div className="mt-auto flex items-center gap-4">
                <div className="flex items-center border border-black">
                  <button
                    type="button"
                    onClick={() => setQuantity(item.key, item.quantity - 1)}
                    aria-label={`Decrease quantity of ${item.name}`}
                    className="px-3 py-1"
                  >
                    -
                  </button>
                  <span className="w-8 text-center" aria-live="polite">
                    {item.quantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => setQuantity(item.key, item.quantity + 1)}
                    aria-label={`Increase quantity of ${item.name}`}
                    className="px-3 py-1"
                  >
                    +
                  </button>
                </div>
                <button type="button" onClick={() => removeItem(item.key)} className="text-sm underline underline-offset-4">
                  Remove
                </button>
              </div>
            </div>
          </li>
        ))}
      </ul>

      <div className="mt-6 flex justify-between text-xl">
        <span>SUBTOTAL</span>
        <span>{formatPrice(subtotal)}</span>
      </div>

      <Link href="/checkout" className="mt-10 block bg-black py-5 text-center text-lg tracking-widest text-white">
        PURCHASE
      </Link>
    </section>
  )
}
