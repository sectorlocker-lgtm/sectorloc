import Image from 'next/image'
import { ProductCardLink } from './product-card-link'
import { formatPrice } from '@/lib/format'
import { isSoldOut, type Product } from '@/lib/types'

export function ProductGrid({ title, products }: { title: string; products: Product[] }) {
  return (
    <section className="px-4 pt-10 md:px-10">
      <h1 className="text-balance text-center text-4xl uppercase md:text-5xl">{title}</h1>
      {products.length === 0 ? (
        <p className="mt-16 text-center text-lg text-neutral-500">Nothing here yet. Check back soon.</p>
      ) : (
        <ul className="mx-auto mt-10 grid max-w-6xl grid-cols-2 gap-x-4 gap-y-14 md:grid-cols-3 md:gap-x-8">
          {products.map((product) => (
            <li key={product.id}>
              <ProductCard product={product} />
            </li>
          ))}
        </ul>
      )}
    </section>
  )
}

function ProductCard({ product }: { product: Product }) {
  const soldOut = isSoldOut(product)
  const onSale = product.compareAtPrice !== null && product.compareAtPrice > product.price

  return (
    <ProductCardLink href={`/products/${product.slug}`} image={product.images[0]} name={product.name}>
      <div className="relative aspect-square overflow-hidden bg-white">
        <Image
          src={product.images[0] || '/placeholder.svg'}
          alt={product.name}
          fill
          sizes="(min-width: 768px) 33vw, 50vw"
          className="object-contain transition-transform duration-500 group-hover:scale-105"
        />
      </div>
      <h2 className="mt-6 text-balance text-lg uppercase leading-snug md:text-xl">{product.name}</h2>
      <p className="mt-3 flex flex-wrap items-center justify-center gap-x-3 gap-y-1 text-sm md:text-base">
        {onSale ? (
          <>
            <span className="text-red-600">{formatPrice(product.price)}</span>
            <s className="text-black">{formatPrice(product.compareAtPrice!)}</s>
          </>
        ) : (
          <span>
            {formatPrice(product.price)}
            {soldOut && ' — Sold out'}
          </span>
        )}
        {onSale && soldOut && <span>— Sold out</span>}
      </p>
    </ProductCardLink>
  )
}
