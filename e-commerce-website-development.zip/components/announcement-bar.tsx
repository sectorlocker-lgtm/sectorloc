export function AnnouncementBar({ text }: { text: string }) {
  if (!text) return null
  const items = Array.from({ length: 8 })

  return (
    <div className="overflow-hidden bg-black py-3 text-white" aria-label={text}>
      <div className="animate-marquee flex w-max" aria-hidden="true">
        {[0, 1].map((group) => (
          <div key={group} className="flex shrink-0">
            {items.map((_, i) => (
              <span key={i} className="px-10 text-sm font-bold tracking-tight md:text-base">
                {text}
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}
