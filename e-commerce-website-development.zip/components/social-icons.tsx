export function SocialIcons() {
  return (
    <ul className="mt-16 flex items-center justify-center gap-10">
      <li>
        <a href="https://instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram">
          <svg viewBox="0 0 24 24" className="size-8" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
            <rect x="3" y="3" width="18" height="18" rx="5" />
            <circle cx="12" cy="12" r="4" />
            <circle cx="17.5" cy="6.5" r="0.6" fill="currentColor" />
          </svg>
        </a>
      </li>
      <li>
        <a href="https://youtube.com" target="_blank" rel="noreferrer" aria-label="YouTube">
          <svg viewBox="0 0 24 24" className="size-9" fill="currentColor" aria-hidden="true">
            <path d="M21.6 7.2a2.5 2.5 0 0 0-1.8-1.8C18.2 5 12 5 12 5s-6.2 0-7.8.4A2.5 2.5 0 0 0 2.4 7.2 26 26 0 0 0 2 12a26 26 0 0 0 .4 4.8 2.5 2.5 0 0 0 1.8 1.8C5.8 19 12 19 12 19s6.2 0 7.8-.4a2.5 2.5 0 0 0 1.8-1.8A26 26 0 0 0 22 12a26 26 0 0 0-.4-4.8ZM10 15V9l5.2 3L10 15Z" />
          </svg>
        </a>
      </li>
      <li>
        <a href="https://tiktok.com" target="_blank" rel="noreferrer" aria-label="TikTok">
          <svg viewBox="0 0 24 24" className="size-8" fill="currentColor" aria-hidden="true">
            <path d="M16.6 5.8A4.3 4.3 0 0 1 15.5 3h-3.1v12.4a2.6 2.6 0 1 1-2.6-2.6c.3 0 .5 0 .8.1V9.7a5.7 5.7 0 1 0 4.9 5.7V9a7.3 7.3 0 0 0 4.3 1.4V7.3a4.3 4.3 0 0 1-3.2-1.5Z" />
          </svg>
        </a>
      </li>
    </ul>
  )
}
