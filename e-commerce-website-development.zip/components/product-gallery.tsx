'use client'

import Image from 'next/image'
import { useRef, useState } from 'react'

export function ProductGallery({ images, name }: { images: string[]; name: string }) {
  const [active, setActive] = useState(0)
  const trackRef = useRef<HTMLDivElement>(null)

  const goTo = (index: number) => {
    const track = trackRef.current
    if (track) track.scrollTo({ left: track.clientWidth * index, behavior: 'smooth' })
  }

  return (
    <div>
      <div
        ref={trackRef}
        onScroll={(e) => {
          const el = e.currentTarget
          setActive(Math.round(el.scrollLeft / el.clientWidth))
        }}
        className="no-scrollbar flex snap-x snap-mandatory overflow-x-auto"
      >
        {images.map((src, i) => (
          <div key={src + i} className="relative aspect-square w-full shrink-0 snap-center">
            <Image
              src={src || '/placeholder.svg'}
              alt={`${name} — image ${i + 1}`}
              fill
              priority={i === 0}
              sizes="(min-width: 768px) 50vw, 100vw"
              className="object-contain"
            />
          </div>
        ))}
      </div>
      {images.length > 1 && (
        <div className="mt-4 flex justify-center gap-3">
          {images.map((_, i) => (
            <button
              key={i}
              type="button"
              onClick={() => goTo(i)}
              aria-label={`Show image ${i + 1}`}
              aria-current={active === i}
              className={`size-3 rounded-full border border-black ${active === i ? 'bg-black' : 'bg-white'}`}
            />
          ))}
        </div>
      )}
    </div>
  )
}
