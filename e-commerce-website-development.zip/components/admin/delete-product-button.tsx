'use client'

import { deleteProductAction } from '@/app/admin/actions'

export function DeleteProductButton({ id, name }: { id: string; name: string }) {
  return (
    <form
      action={deleteProductAction}
      onSubmit={(e) => {
        if (!window.confirm(`Delete "${name}"? This cannot be undone.`)) e.preventDefault()
      }}
    >
      <input type="hidden" name="id" value={id} />
      <button type="submit" className="text-red-600 underline underline-offset-4">
        Delete
      </button>
    </form>
  )
}
