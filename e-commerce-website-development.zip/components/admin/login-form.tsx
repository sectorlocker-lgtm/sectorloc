'use client'

import { useActionState } from 'react'
import { loginAction } from '@/app/admin/actions'

export function LoginForm() {
  const [state, formAction, pending] = useActionState(loginAction, null)

  return (
    <form action={formAction} className="mx-auto mt-16 flex max-w-sm flex-col gap-4 border border-neutral-200 bg-white p-8">
      <h1 className="text-center text-2xl uppercase">Admin login</h1>
      <label className="flex flex-col gap-2">
        <span className="text-sm">Password</span>
        <input
          name="password"
          type="password"
          required
          autoComplete="current-password"
          className="border-2 border-black px-4 py-3 outline-none"
        />
      </label>
      {state && !state.ok && (
        <p role="alert" className="text-sm text-red-600">
          {state.message}
        </p>
      )}
      <button type="submit" disabled={pending} className="bg-black py-4 tracking-widest text-white disabled:opacity-70">
        {pending ? 'SIGNING IN...' : 'SIGN IN'}
      </button>
    </form>
  )
}
