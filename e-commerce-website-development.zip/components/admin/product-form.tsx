'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useActionState, useEffect, useState } from 'react'
import { X } from 'lucide-react'
import { saveProductAction } from '@/app/admin/actions'
import { SIZE_OPTIONS, type Product } from '@/lib/types'

const inputClass = 'w-full border border-neutral-300 bg-white px-3 py-2 outline-none focus:border-black'

export function ProductForm({ product }: { product?: Product }) {
  const [state, formAction, pending] = useActionState(saveProductAction, null)
  const [images, setImages] = useState<string[]>(product?.images ?? [])
  const [previews, setPreviews] = useState<string[]>([])

  useEffect(() => () => previews.forEach((url) => URL.revokeObjectURL(url)), [previews])

  const availableSizes = new Set(
    product ? product.sizes.filter((s) => s.available).map((s) => s.label) : SIZE_OPTIONS,
  )

  return (
    <form action={formAction} className="mt-6 flex flex-col gap-6 border border-neutral-200 bg-white p-5 md:p-8">
      {product && <input type="hidden" name="id" value={product.id} />}

      <label className="flex flex-col gap-1">
        <span className="text-sm">Product name</span>
        <input name="name" required defaultValue={product?.name} placeholder="Forest Thermal (White)" className={inputClass} />
      </label>

      <div className="grid gap-4 sm:grid-cols-2">
        <label className="flex flex-col gap-1">
          <span className="text-sm">Price (Tk)</span>
          <input name="price" type="number" min="1" step="0.01" required defaultValue={product?.price} className={inputClass} />
        </label>
        <label className="flex flex-col gap-1">
          <span className="text-sm">Original price (optional, shows as sale)</span>
          <input
            name="compareAtPrice"
            type="number"
            min="1"
            step="0.01"
            defaultValue={product?.compareAtPrice ?? ''}
            className={inputClass}
          />
        </label>
      </div>

      <label className="flex flex-col gap-1">
        <span className="text-sm">Description</span>
        <textarea name="description" rows={5} defaultValue={product?.description} className={inputClass} />
      </label>

      <fieldset>
        <legend className="text-sm">Sizes in stock (unchecked = sold out)</legend>
        <div className="mt-2 flex flex-wrap gap-3">
          {SIZE_OPTIONS.map((size) => (
            <label key={size} className="flex items-center gap-2 border border-neutral-300 px-3 py-2 text-sm">
              <input type="checkbox" name="sizes" value={size} defaultChecked={availableSizes.has(size)} />
              {size}
            </label>
          ))}
        </div>
      </fieldset>

      <fieldset>
        <legend className="text-sm">Images (first image is the main photo)</legend>
        <div className="mt-2 grid grid-cols-3 gap-3 sm:grid-cols-5">
          {images.map((src) => (
            <div key={src} className="relative aspect-square border border-neutral-200 bg-neutral-50">
              <input type="hidden" name="keepImages" value={src} />
              <Image src={src || '/placeholder.svg'} alt="" fill sizes="120px" className="object-contain" />
              <button
                type="button"
                onClick={() => setImages((prev) => prev.filter((s) => s !== src))}
                aria-label="Remove image"
                className="absolute right-1 top-1 bg-black p-1 text-white"
              >
                <X className="size-3" />
              </button>
            </div>
          ))}
          {previews.map((src) => (
            <div key={src} className="relative aspect-square border border-dashed border-black bg-neutral-50">
              {/* eslint-disable-next-line @next/next/no-img-element -- local blob preview */}
              <img src={src || '/placeholder.svg'} alt="" className="size-full object-contain" />
              <span className="absolute bottom-1 left-1 bg-black px-1 text-[10px] text-white">NEW</span>
            </div>
          ))}
        </div>
        <label className="mt-3 flex cursor-pointer flex-col items-center justify-center gap-1 border-2 border-dashed border-neutral-300 p-6 text-center text-sm hover:border-black">
          <span className="font-bold">Upload photos</span>
          <span className="text-neutral-500">JPG, PNG, WEBP — up to 8MB each</span>
          <input
            type="file"
            name="newImages"
            accept="image/jpeg,image/png,image/webp,image/gif,image/avif"
            multiple
            className="sr-only"
            onChange={(e) => setPreviews(Array.from(e.target.files ?? []).map((f) => URL.createObjectURL(f)))}
          />
        </label>
      </fieldset>

      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" name="archived" defaultChecked={product?.archived} />
        Move to Archives (hide from home &amp; catalog)
      </label>

      {state && !state.ok && (
        <p role="alert" className="text-sm text-red-600">
          {state.message}
        </p>
      )}

      <div className="flex items-center gap-4">
        <button type="submit" disabled={pending} className="bg-black px-8 py-3 tracking-widest text-white disabled:opacity-70">
          {pending ? 'SAVING...' : product ? 'SAVE CHANGES' : 'PUBLISH'}
        </button>
        <Link href="/admin" className="text-sm underline underline-offset-4">
          Cancel
        </Link>
      </div>
    </form>
  )
}
