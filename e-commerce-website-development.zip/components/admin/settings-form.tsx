'use client'

import { useActionState } from 'react'
import { saveSettingsAction } from '@/app/admin/actions'
import type { Settings } from '@/lib/types'

const inputClass = 'border border-neutral-300 bg-white px-3 py-2 outline-none focus:border-black'

export function SettingsForm({ settings }: { settings: Settings }) {
  const [state, formAction, pending] = useActionState(saveSettingsAction, null)

  return (
    <form action={formAction} className="mt-5 flex flex-col gap-4 border border-neutral-200 bg-white p-5">
      <label className="flex flex-col gap-1">
        <span className="text-sm">Announcement bar text</span>
        <input name="announcement" defaultValue={settings.announcement} className={inputClass} />
      </label>
      <label className="flex flex-col gap-1">
        <span className="text-sm">Homepage collection title</span>
        <input name="collectionTitle" defaultValue={settings.collectionTitle} className={inputClass} />
      </label>
      <div className="flex items-center gap-4">
        <button type="submit" disabled={pending} className="bg-black px-5 py-2 text-sm tracking-widest text-white">
          {pending ? 'SAVING...' : 'SAVE'}
        </button>
        {state && (
          <p role="status" className="text-sm">
            {state.message}
          </p>
        )}
      </div>
    </form>
  )
}
