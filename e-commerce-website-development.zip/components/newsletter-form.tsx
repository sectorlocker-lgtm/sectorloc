'use client'

import { useActionState } from 'react'
import { subscribeAction } from '@/app/(shop)/actions'

export function NewsletterForm() {
  const [state, formAction, pending] = useActionState(subscribeAction, null)

  return (
    <form action={formAction} className="mt-10">
      <div className="flex border-2 border-black">
        <label htmlFor="newsletter-email" className="sr-only">
          Email
        </label>
        <input
          id="newsletter-email"
          name="email"
          type="email"
          required
          placeholder="Your Email"
          className="min-w-0 flex-1 bg-white px-5 py-4 text-lg outline-none placeholder:text-neutral-400"
        />
        <button
          type="submit"
          disabled={pending}
          className="bg-black px-6 text-lg tracking-wide text-white disabled:opacity-70"
        >
          {pending ? '...' : 'SUBSCRIBE'}
        </button>
      </div>
      {state && (
        <p role="status" className={`mt-3 text-sm ${state.ok ? 'text-black' : 'text-red-600'}`}>
          {state.message}
        </p>
      )}
    </form>
  )
}
