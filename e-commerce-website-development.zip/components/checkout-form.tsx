'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useActionState, useEffect, useState } from 'react'
import { placeOrderAction } from '@/app/(shop)/actions'
import { formatPrice } from '@/lib/format'
import { useCart } from './cart-provider'

export type CheckoutItem = {
  productId: string
  name: string
  price: number
  image: string
  size: string
  quantity: number
}

const BKASH_NUMBER = '01711405548'
const inputClass = 'w-full border-2 border-black bg-white px-4 py-4 text-base outline-none focus:bg-neutral-50'

export function CheckoutForm({ directItem }: { directItem: CheckoutItem | null }) {
  const cart = useCart()
  const [state, formAction, pending] = useActionState(placeOrderAction, null)
  const [copied, setCopied] = useState(false)

  const items: CheckoutItem[] = directItem ? [directItem] : cart.items
  const total = items.reduce((sum, i) => sum + i.price * i.quantity, 0)

  useEffect(() => {
    if (state?.ok && !directItem) cart.clear()
  }, [state, directItem, cart])

  const copyNumber = async () => {
    try {
      await navigator.clipboard.writeText(BKASH_NUMBER)
      setCopied(true)
      setTimeout(() => setCopied(false), 1500)
    } catch {}
  }

  if (state?.ok) {
    return (
      <section className="mx-auto max-w-xl px-6 pt-16 text-center">
        <h1 className="text-4xl uppercase">Order placed</h1>
        <p className="mt-6 text-pretty text-lg leading-relaxed">
          Thank you. Your order <strong>#{state.orderId}</strong> has been received. We&apos;ll verify your bKash
          payment and call you to confirm delivery.
        </p>
        <Link href="/" className="mt-10 inline-block bg-black px-10 py-4 tracking-widest text-white">
          CONTINUE SHOPPING
        </Link>
      </section>
    )
  }

  if (items.length === 0) {
    return (
      <section className="mx-auto max-w-xl px-6 pt-16 text-center">
        <h1 className="text-4xl uppercase">Nothing to checkout</h1>
        <Link href="/catalog" className="mt-10 inline-block bg-black px-10 py-4 tracking-widest text-white">
          CONTINUE SHOPPING
        </Link>
      </section>
    )
  }

  return (
    <section className="mx-auto max-w-xl px-6 pt-10">
      <h1 className="text-center text-4xl uppercase">Buy</h1>

      <ul className="mt-8 divide-y divide-neutral-200 border-y border-neutral-200">
        {items.map((item) => (
          <li key={item.productId + item.size} className="flex items-center gap-4 py-4">
            <div className="relative size-20 shrink-0">
              <Image src={item.image || '/placeholder.svg'} alt={item.name} fill sizes="80px" className="object-contain" />
            </div>
            <div className="flex-1">
              <p className="uppercase">{item.name}</p>
              <p className="text-sm text-neutral-500">
                Size: {item.size} · Qty: {item.quantity}
              </p>
            </div>
            <p className="shrink-0">{formatPrice(item.price * item.quantity, false)}</p>
          </li>
        ))}
      </ul>
      <div className="mt-4 flex justify-between text-xl">
        <span>TOTAL</span>
        <span>{formatPrice(total)}</span>
      </div>

      <div className="mt-10 bg-black p-6 text-white">
        <p className="text-sm tracking-[0.3em] text-neutral-400">PAYMENT</p>
        <p className="mt-3 text-2xl uppercase">bKash — Send Money</p>
        <div className="mt-4 flex items-center justify-between gap-4 border border-white/30 px-4 py-3">
          <span className="font-mono text-2xl tracking-wider">{BKASH_NUMBER}</span>
          <button type="button" onClick={copyNumber} className="text-sm underline underline-offset-4">
            {copied ? 'Copied' : 'Copy'}
          </button>
        </div>
        <p className="mt-4 text-pretty leading-relaxed text-neutral-300">
          Send <strong className="text-white">{formatPrice(total)}</strong> to the number above using bKash
          &quot;Send Money&quot;, then enter your details and the transaction ID below.
        </p>
      </div>

      <form action={formAction} className="mt-8 flex flex-col gap-5">
        <input
          type="hidden"
          name="items"
          value={JSON.stringify(items.map((i) => ({ productId: i.productId, size: i.size, quantity: i.quantity })))}
        />
        <label className="flex flex-col gap-2">
          <span className="text-sm uppercase tracking-wide">Your name</span>
          <input name="name" required maxLength={100} autoComplete="name" className={inputClass} />
        </label>
        <label className="flex flex-col gap-2">
          <span className="text-sm uppercase tracking-wide">Your address</span>
          <textarea
            name="address"
            required
            rows={3}
            maxLength={500}
            autoComplete="street-address"
            className={inputClass}
          />
        </label>
        <label className="flex flex-col gap-2">
          <span className="text-sm uppercase tracking-wide">Your phone number</span>
          <input
            name="phone"
            type="tel"
            required
            autoComplete="tel"
            placeholder="01XXXXXXXXX"
            className={inputClass}
          />
        </label>
        <label className="flex flex-col gap-2">
          <span className="text-sm uppercase tracking-wide">bKash transaction ID</span>
          <input
            name="transactionId"
            required
            maxLength={30}
            autoCapitalize="characters"
            placeholder="e.g. 9JK3L7XQ2P"
            className={`${inputClass} font-mono uppercase`}
          />
        </label>
        {state && !state.ok && (
          <p role="alert" className="text-red-600">
            {state.message}
          </p>
        )}
        <button
          type="submit"
          disabled={pending}
          className="mt-2 bg-black py-5 text-lg tracking-widest text-white disabled:opacity-70"
        >
          {pending ? 'PLACING ORDER...' : 'PLACE ORDER'}
        </button>
      </form>
    </section>
  )
}
