'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useEffect, useRef, useState } from 'react'

const TRANSITION_MS = 1500

type Props = {
  href: string
  image: string
  name: string
  children: React.ReactNode
}

export function ProductCardLink({ href, image, name, children }: Props) {
  const router = useRouter()
  const [opening, setOpening] = useState(false)
  const timer = useRef<ReturnType<typeof setTimeout>>(undefined)

  useEffect(() => () => clearTimeout(timer.current), [])

  const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return
    e.preventDefault()
    if (opening) return
    setOpening(true)
    router.prefetch(href)
    timer.current = setTimeout(() => router.push(href), TRANSITION_MS)
  }

  return (
    <>
      <Link href={href} onClick={handleClick} className="group block text-center">
        {children}
      </Link>
      {opening && (
        <div
          role="status"
          aria-live="polite"
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center gap-10 bg-white animate-overlay-in"
        >
          <span className="sr-only">Opening {name}</span>
          <div className="relative size-64 animate-product-reveal md:size-96">
            <Image src={image || '/placeholder.svg'} alt="" fill sizes="384px" className="object-contain" priority />
          </div>
          <p className="animate-fade-up text-center text-xl uppercase tracking-widest">{name}</p>
          <div className="h-px w-48 overflow-hidden bg-neutral-200">
            <div className="h-full w-full origin-left animate-progress bg-black" />
          </div>
        </div>
      )}
    </>
  )
}
