'use client'

import Image from 'next/image'
import Link from 'next/link'
import { useEffect, useState } from 'react'
import { usePathname } from 'next/navigation'
import { X } from 'lucide-react'
import { useCart } from './cart-provider'

const NAV_LINKS = [
  { href: '/', label: 'HOME' },
  { href: '/catalog', label: 'CATALOG' },
  { href: '/contact', label: 'CONTACT' },
  { href: '/archives', label: 'ARCHIVES' },
  { href: '/admin', label: 'ACCOUNT' },
]

export function SiteHeader() {
  const [open, setOpen] = useState(false)
  const { count } = useCart()
  const pathname = usePathname()

  useEffect(() => setOpen(false), [pathname])

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
    return () => {
      document.body.style.overflow = ''
    }
  }, [open])

  return (
    <>
      <header className="sticky top-0 z-40 bg-white">
        <div className="relative flex h-20 items-center justify-between px-6 md:px-10">
          <button
            type="button"
            onClick={() => setOpen(true)}
            aria-label="Open menu"
            aria-expanded={open}
            className="flex h-10 w-12 flex-col justify-center gap-2"
          >
            <span className="block h-px w-10 bg-black" />
            <span className="block h-px w-10 bg-black" />
          </button>

          <Link href="/" aria-label="SectorLocker home" className="absolute left-1/2 -translate-x-1/2">
            <Image src="/logo.jpeg" alt="SectorLocker" width={130} height={70} priority className="h-14 w-auto" />
          </Link>

          <Link href="/cart" className="text-base tracking-wide md:text-lg">
            CART ({count})
          </Link>
        </div>
      </header>

      {open && (
        <div role="dialog" aria-modal="true" aria-label="Menu" className="fixed inset-0 z-50 flex flex-col bg-white">
          <div className="px-6 py-6 md:px-10">
            <button type="button" onClick={() => setOpen(false)} aria-label="Close menu" className="p-1">
              <X className="size-8 stroke-1" />
            </button>
          </div>
          <nav className="flex flex-1 flex-col items-center justify-center gap-8 pb-24">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="text-4xl tracking-wide transition-opacity hover:opacity-60 md:text-5xl"
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </>
  )
}
