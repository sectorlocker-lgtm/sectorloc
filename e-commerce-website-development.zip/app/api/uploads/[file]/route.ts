import { promises as fs } from 'fs'
import path from 'path'
import { UPLOAD_DIR } from '@/lib/store'

const CONTENT_TYPES: Record<string, string> = {
  '.jpg': 'image/jpeg',
  '.png': 'image/png',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.avif': 'image/avif',
}

export async function GET(_req: Request, { params }: { params: Promise<{ file: string }> }) {
  const { file } = await params
  const name = path.basename(file)
  const type = CONTENT_TYPES[path.extname(name).toLowerCase()]
  if (!type) return new Response('Not found', { status: 404 })

  try {
    const data = await fs.readFile(path.join(UPLOAD_DIR, name))
    return new Response(data, {
      headers: { 'Content-Type': type, 'Cache-Control': 'public, max-age=31536000, immutable' },
    })
  } catch {
    return new Response('Not found', { status: 404 })
  }
}
