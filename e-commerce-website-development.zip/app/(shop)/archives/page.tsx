import type { Metadata } from 'next'
import { ProductGrid } from '@/components/product-grid'
import { getProducts } from '@/lib/store'

export const metadata: Metadata = { title: 'Archives' }

export default async function ArchivesPage() {
  const products = await getProducts()
  return <ProductGrid title="ARCHIVES" products={products.filter((p) => p.archived)} />
}
