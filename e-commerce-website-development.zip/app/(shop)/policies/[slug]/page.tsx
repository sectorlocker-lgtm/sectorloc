import type { Metadata } from 'next'
import { notFound } from 'next/navigation'

const POLICIES: Record<string, { title: string; body: string[] }> = {
  'refund-policy': {
    title: 'Refund Policy',
    body: [
      'We accept returns within 7 days of delivery for unworn items with original tags attached.',
      'Sale items are final sale. To start a return, contact us with your order number.',
      'Refunds are processed within 5–7 business days after we receive and inspect the item.',
    ],
  },
  'privacy-policy': {
    title: 'Privacy Policy',
    body: [
      'We only collect the information needed to process your order and send updates you sign up for.',
      'We never sell your personal data. You can unsubscribe from emails at any time.',
    ],
  },
  'terms-of-service': {
    title: 'Terms of Service',
    body: [
      'By using this website you agree to these terms. Prices and availability may change without notice.',
      'All designs, logos and content are the property of SectorLocker.',
    ],
  },
  'shipping-policy': {
    title: 'Shipping Policy',
    body: [
      'Orders are dispatched within 2–4 business days. Delivery inside Dhaka takes 1–3 days, outside Dhaka 3–5 days.',
      'Cash on delivery is available nationwide. You will receive a call to confirm your order.',
    ],
  },
}

type Props = { params: Promise<{ slug: string }> }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const policy = POLICIES[(await params).slug]
  return policy ? { title: policy.title } : {}
}

export default async function PolicyPage({ params }: Props) {
  const policy = POLICIES[(await params).slug]
  if (!policy) notFound()

  return (
    <section className="mx-auto max-w-2xl px-6 pt-10">
      <h1 className="text-center text-4xl uppercase">{policy.title}</h1>
      <div className="mt-10 flex flex-col gap-5 text-lg leading-relaxed">
        {policy.body.map((p) => (
          <p key={p}>{p}</p>
        ))}
      </div>
    </section>
  )
}
