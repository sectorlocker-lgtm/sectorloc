'use server'

import { addOrder, addSubscriber, getProducts } from '@/lib/store'
import type { OrderItem } from '@/lib/types'

type Result = { ok: boolean; message: string; orderId?: string } | null

export async function subscribeAction(_prev: Result, formData: FormData): Promise<Result> {
  const email = String(formData.get('email') ?? '').trim().toLowerCase()
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 200) {
    return { ok: false, message: 'Please enter a valid email.' }
  }
  await addSubscriber(email)
  return { ok: true, message: "Thanks for subscribing. You're on the list." }
}

const MAX_QTY_PER_LINE = 10
const MAX_ITEMS_PER_ORDER = 20

export async function placeOrderAction(_prev: Result, formData: FormData): Promise<Result> {
  const name = String(formData.get('name') ?? '').trim()
  const phone = String(formData.get('phone') ?? '').trim()
  const address = String(formData.get('address') ?? '').trim()

  if (!name || name.length > 100) return { ok: false, message: 'Please enter your name.' }
  if (!/^[+\d][\d\s-]{6,19}$/.test(phone)) return { ok: false, message: 'Please enter a valid phone number.' }
  if (address.length < 5 || address.length > 500) return { ok: false, message: 'Please enter your full address.' }
  const transactionId = String(formData.get('transactionId') ?? '').trim().toUpperCase()
  if (!/^[A-Z0-9]{6,30}$/.test(transactionId)) {
    return { ok: false, message: 'Please enter a valid bKash transaction ID.' }
  }

  let requested: { productId: string; size: string; quantity: number }[]
  try {
    requested = JSON.parse(String(formData.get('items') ?? '[]'))
    if (!Array.isArray(requested) || requested.length === 0) throw new Error()
  } catch {
    return { ok: false, message: 'Your cart is empty.' }
  }

  const products = await getProducts()
  const items: OrderItem[] = []
  let totalQty = 0

  for (const line of requested) {
    const quantity = Number(line.quantity)
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > MAX_QTY_PER_LINE) {
      return { ok: false, message: 'Invalid quantity in cart.' }
    }
    const product = products.find((p) => p.id === line.productId && !p.archived)
    const size = product?.sizes.find((s) => s.label === line.size)
    if (!product || !size?.available) {
      return { ok: false, message: 'An item in your cart is no longer available.' }
    }
    totalQty += quantity
    items.push({ productId: product.id, name: product.name, size: size.label, price: product.price, quantity })
  }

  if (totalQty > MAX_ITEMS_PER_ORDER) {
    return { ok: false, message: `Orders are limited to ${MAX_ITEMS_PER_ORDER} items.` }
  }

  const total = items.reduce((sum, i) => sum + i.price * i.quantity, 0)
  const order = await addOrder({ name, phone, address, transactionId, items, total })
  return { ok: true, message: 'Order placed', orderId: order.id }
}
