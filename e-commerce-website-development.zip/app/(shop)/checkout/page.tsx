import type { Metadata } from 'next'
import { CheckoutForm, type CheckoutItem } from '@/components/checkout-form'
import { getProductBySlug } from '@/lib/store'

export const metadata: Metadata = { title: 'Checkout' }

type Props = { searchParams: Promise<{ product?: string; size?: string }> }

export default async function CheckoutPage({ searchParams }: Props) {
  const { product: slug, size } = await searchParams

  let directItem: CheckoutItem | null = null
  if (slug && size) {
    const product = await getProductBySlug(slug)
    const sizeOption = product?.sizes.find((s) => s.label === size)
    if (product && !product.archived && sizeOption?.available) {
      directItem = {
        productId: product.id,
        name: product.name,
        price: product.price,
        image: product.images[0] ?? '',
        size: sizeOption.label,
        quantity: 1,
      }
    }
  }

  return <CheckoutForm directItem={directItem} />
}
