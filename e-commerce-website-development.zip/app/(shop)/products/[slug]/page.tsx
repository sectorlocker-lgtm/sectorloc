import type { Metadata } from 'next'
import Image from 'next/image'
import { notFound } from 'next/navigation'
import { AddToCart } from '@/components/add-to-cart'
import { ProductGallery } from '@/components/product-gallery'
import { formatPrice } from '@/lib/format'
import { getProductBySlug } from '@/lib/store'

type Props = { params: Promise<{ slug: string }> }

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const product = await getProductBySlug((await params).slug)
  return product ? { title: product.name, description: product.description.slice(0, 160) } : {}
}

const MATERIAL_SPECS = [
  { label: '300gsm', detail: 'Keeps you warm all year round' },
  { label: 'Hand sewn', detail: 'Holds its shape wash after wash' },
  { label: '100% cotton', detail: 'Soft, breathable, built to last' },
]

export default async function ProductPage({ params }: Props) {
  const product = await getProductBySlug((await params).slug)
  if (!product) notFound()

  const onSale = product.compareAtPrice !== null && product.compareAtPrice > product.price

  return (
    <article className="mx-auto max-w-6xl md:grid md:grid-cols-2 md:gap-12 md:px-10 md:pt-10">
      <ProductGallery images={product.images} name={product.name} />

      <div className="px-6 pt-8 md:px-0">
        <div className="flex items-start justify-between gap-6">
          <h1 className="text-2xl uppercase leading-snug md:text-3xl">{product.name}</h1>
          <p className="flex shrink-0 gap-3 text-xl md:text-2xl">
            {onSale && <s className="text-neutral-500">{formatPrice(product.compareAtPrice!, false)}</s>}
            <span>{formatPrice(product.price, false)}</span>
          </p>
        </div>

        <AddToCart
          product={{
            id: product.id,
            slug: product.slug,
            name: product.name,
            price: product.price,
            image: product.images[0] ?? '',
            sizes: product.sizes,
          }}
        />

        {product.description && (
          <p className="mt-10 text-pretty text-lg leading-relaxed text-neutral-800">{product.description}</p>
        )}
      </div>

      <section className="px-6 pt-24 md:col-span-2 md:px-0">
        <div className="relative aspect-[3/2] w-full overflow-hidden">
          <Image src="/material.png" alt="Close-up of the waffle knit fabric" fill sizes="100vw" className="object-cover" />
        </div>
        <p className="mt-10 text-sm tracking-[0.3em] text-neutral-500">the material we use</p>
        <h2 className="mt-6 text-balance text-4xl uppercase leading-tight md:text-5xl">100% Cotton Waffle Knit</h2>
        <p className="mt-8 max-w-3xl text-pretty text-lg leading-loose">
          {
            "A dense waffle knit with a raised grid texture that holds warmth close without adding bulk. Crafted by hand, it was chosen for its weight and structure, keeping the perfect fit sharp wash after wash. We promise you won't find anything comfier."
          }
        </p>
        <dl className="mt-10 border-t border-neutral-200">
          {MATERIAL_SPECS.map((spec) => (
            <div key={spec.label} className="flex items-center justify-between gap-6 border-b border-neutral-200 py-7">
              <dt className="text-lg">{spec.label}</dt>
              <dd className="text-right text-lg text-neutral-500">{spec.detail}</dd>
            </div>
          ))}
        </dl>
      </section>
    </article>
  )
}
