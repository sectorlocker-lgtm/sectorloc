import type { Metadata } from 'next'
import { ProductGrid } from '@/components/product-grid'
import { getProducts } from '@/lib/store'

export const metadata: Metadata = { title: 'Catalog' }

export default async function CatalogPage() {
  const products = await getProducts()
  return <ProductGrid title="CATALOG" products={products.filter((p) => !p.archived)} />
}
