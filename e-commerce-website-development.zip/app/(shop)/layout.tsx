import { AnnouncementBar } from '@/components/announcement-bar'
import { SiteFooter } from '@/components/site-footer'
import { SiteHeader } from '@/components/site-header'
import { getSettings } from '@/lib/store'

export const dynamic = 'force-dynamic'

export default async function ShopLayout({ children }: { children: React.ReactNode }) {
  const settings = await getSettings()

  return (
    <>
      <SiteHeader />
      <AnnouncementBar text={settings.announcement} />
      <main>{children}</main>
      <SiteFooter />
    </>
  )
}
