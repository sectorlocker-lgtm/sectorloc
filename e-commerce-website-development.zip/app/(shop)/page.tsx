import { ProductGrid } from '@/components/product-grid'
import { getProducts, getSettings } from '@/lib/store'

export default async function HomePage() {
  const [products, settings] = await Promise.all([getProducts(), getSettings()])
  return <ProductGrid title={settings.collectionTitle} products={products.filter((p) => !p.archived)} />
}
