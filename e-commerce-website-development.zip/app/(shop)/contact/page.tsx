import type { Metadata } from 'next'

export const metadata: Metadata = { title: 'Contact' }

export default function ContactPage() {
  return (
    <section className="mx-auto max-w-xl px-6 pt-10 text-center">
      <h1 className="text-4xl uppercase">Contact</h1>
      <p className="mt-8 text-pretty text-lg leading-relaxed">
        Questions about sizing, orders or collaborations? Reach out and we&apos;ll get back to you within 24 hours.
      </p>
      <dl className="mt-10 flex flex-col gap-6 text-lg">
        <div>
          <dt className="text-sm tracking-[0.3em] text-neutral-500">EMAIL</dt>
          <dd className="mt-1">
            <a href="mailto:hello@sectorlocker.com" className="underline underline-offset-4">
              hello@sectorlocker.com
            </a>
          </dd>
        </div>
        <div>
          <dt className="text-sm tracking-[0.3em] text-neutral-500">INSTAGRAM</dt>
          <dd className="mt-1">
            <a href="https://instagram.com" target="_blank" rel="noreferrer" className="underline underline-offset-4">
              @sectorlocker
            </a>
          </dd>
        </div>
        <div>
          <dt className="text-sm tracking-[0.3em] text-neutral-500">LOCATION</dt>
          <dd className="mt-1">Dhaka, Bangladesh</dd>
        </div>
      </dl>
    </section>
  )
}
