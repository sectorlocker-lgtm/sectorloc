'use server'

import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { endAdminSession, isAdmin, startAdminSession, verifyPassword } from '@/lib/auth'
import { deleteProduct, saveSettings, saveUpload, upsertProduct } from '@/lib/store'
import { SIZE_OPTIONS } from '@/lib/types'

type Result = { ok: boolean; message: string } | null

async function requireAdmin() {
  if (!(await isAdmin())) redirect('/admin')
}

export async function loginAction(_prev: Result, formData: FormData): Promise<Result> {
  const password = String(formData.get('password') ?? '')
  if (!verifyPassword(password)) return { ok: false, message: 'Incorrect password.' }
  await startAdminSession()
  redirect('/admin')
}

export async function logoutAction() {
  await endAdminSession()
  redirect('/admin')
}

export async function saveProductAction(_prev: Result, formData: FormData): Promise<Result> {
  await requireAdmin()

  const id = String(formData.get('id') ?? '') || undefined
  const name = String(formData.get('name') ?? '').trim()
  const description = String(formData.get('description') ?? '').trim()
  const price = Number(formData.get('price'))
  const compareRaw = String(formData.get('compareAtPrice') ?? '').trim()
  const compareAtPrice = compareRaw ? Number(compareRaw) : null

  if (!name || name.length > 120) return { ok: false, message: 'Name is required (max 120 characters).' }
  if (!Number.isFinite(price) || price <= 0) return { ok: false, message: 'Price must be greater than 0.' }
  if (compareAtPrice !== null && (!Number.isFinite(compareAtPrice) || compareAtPrice <= 0)) {
    return { ok: false, message: 'Original price must be a positive number.' }
  }
  if (description.length > 3000) return { ok: false, message: 'Description is too long.' }

  const keptImages = formData
    .getAll('keepImages')
    .map(String)
    .filter((src) => src.startsWith('/'))

  const uploaded: string[] = []
  try {
    for (const file of formData.getAll('newImages')) {
      if (file instanceof File && file.size > 0) uploaded.push(await saveUpload(file))
    }
  } catch (error) {
    return { ok: false, message: error instanceof Error ? error.message : 'Image upload failed.' }
  }

  const images = [...keptImages, ...uploaded]
  if (images.length === 0) return { ok: false, message: 'Add at least one image.' }

  const inStock = new Set(formData.getAll('sizes').map(String))
  const sizes = SIZE_OPTIONS.map((label) => ({ label, available: inStock.has(label) }))

  await upsertProduct({
    id,
    name,
    description,
    price,
    compareAtPrice,
    images,
    sizes,
    archived: formData.get('archived') === 'on',
  })

  revalidatePath('/', 'layout')
  redirect('/admin')
}

export async function deleteProductAction(formData: FormData) {
  await requireAdmin()
  const id = String(formData.get('id') ?? '')
  if (id) await deleteProduct(id)
  revalidatePath('/', 'layout')
}

export async function saveSettingsAction(_prev: Result, formData: FormData): Promise<Result> {
  await requireAdmin()
  const announcement = String(formData.get('announcement') ?? '').trim().slice(0, 120)
  const collectionTitle = String(formData.get('collectionTitle') ?? '').trim().slice(0, 80) || 'NEW ARRIVALS'
  await saveSettings({ announcement, collectionTitle })
  revalidatePath('/', 'layout')
  return { ok: true, message: 'Settings saved.' }
}
