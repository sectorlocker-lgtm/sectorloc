import Image from 'next/image'
import Link from 'next/link'
import { LoginForm } from '@/components/admin/login-form'
import { SettingsForm } from '@/components/admin/settings-form'
import { DeleteProductButton } from '@/components/admin/delete-product-button'
import { isAdmin } from '@/lib/auth'
import { formatPrice } from '@/lib/format'
import { getOrders, getProducts, getSettings, getSubscribers } from '@/lib/store'
import { isSoldOut } from '@/lib/types'

export default async function AdminPage() {
  if (!(await isAdmin())) return <LoginForm />

  const [products, settings, orders, subscribers] = await Promise.all([
    getProducts(),
    getSettings(),
    getOrders(),
    getSubscribers(),
  ])

  return (
    <div className="flex flex-col gap-10">
      <section>
        <div className="flex items-center justify-between gap-4">
          <h1 className="text-2xl uppercase">Products ({products.length})</h1>
          <Link href="/admin/products/new" className="bg-black px-5 py-3 text-sm tracking-widest text-white">
            + NEW POST
          </Link>
        </div>
        <ul className="mt-5 divide-y divide-neutral-200 border border-neutral-200 bg-white">
          {products.map((p) => (
            <li key={p.id} className="flex items-center gap-4 p-4">
              <div className="relative size-16 shrink-0 bg-neutral-100">
                <Image src={p.images[0] || '/placeholder.svg'} alt="" fill sizes="64px" className="object-contain" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate uppercase">{p.name}</p>
                <p className="mt-1 flex flex-wrap gap-2 text-sm text-neutral-500">
                  <span>{formatPrice(p.price)}</span>
                  {isSoldOut(p) && <span className="bg-neutral-200 px-2 text-black">Sold out</span>}
                  {p.archived && <span className="bg-neutral-800 px-2 text-white">Archived</span>}
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-4 text-sm">
                <Link href={`/admin/products/${p.id}`} className="underline underline-offset-4">
                  Edit
                </Link>
                <DeleteProductButton id={p.id} name={p.name} />
              </div>
            </li>
          ))}
        </ul>
      </section>

      <section>
        <h2 className="text-2xl uppercase">Store settings</h2>
        <SettingsForm settings={settings} />
      </section>

      <section>
        <h2 className="text-2xl uppercase">Orders ({orders.length})</h2>
        {orders.length === 0 ? (
          <p className="mt-4 text-neutral-500">No orders yet.</p>
        ) : (
          <ul className="mt-5 flex flex-col gap-3">
            {orders.map((o) => (
              <li key={o.id} className="border border-neutral-200 bg-white p-4 text-sm">
                <div className="flex flex-wrap justify-between gap-2">
                  <p className="font-bold">#{o.id}</p>
                  <p className="text-neutral-500">{new Date(o.createdAt).toLocaleString()}</p>
                </div>
                <p className="mt-2">
                  {o.name} — {o.phone}
                </p>
                <p className="text-neutral-600">{o.address}</p>
                <p className="mt-2">
                  bKash TrxID: <span className="bg-neutral-100 px-2 py-0.5 font-mono font-bold">{o.transactionId}</span>
                </p>
                <ul className="mt-2 text-neutral-700">
                  {o.items.map((i) => (
                    <li key={i.productId + i.size}>
                      {i.quantity} x {i.name} ({i.size}) — {formatPrice(i.price * i.quantity, false)}
                    </li>
                  ))}
                </ul>
                <p className="mt-2 font-bold">Total: {formatPrice(o.total)}</p>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section>
        <h2 className="text-2xl uppercase">Email subscribers ({subscribers.length})</h2>
        {subscribers.length === 0 ? (
          <p className="mt-4 text-neutral-500">No subscribers yet.</p>
        ) : (
          <ul className="mt-4 divide-y divide-neutral-200 border border-neutral-200 bg-white text-sm">
            {subscribers.map((s) => (
              <li key={s.email} className="flex justify-between gap-4 p-3">
                <span>{s.email}</span>
                <span className="text-neutral-500">{new Date(s.createdAt).toLocaleDateString()}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  )
}
