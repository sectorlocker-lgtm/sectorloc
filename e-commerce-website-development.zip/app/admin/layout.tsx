import type { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import { isAdmin } from '@/lib/auth'
import { logoutAction } from './actions'

export const dynamic = 'force-dynamic'
export const metadata: Metadata = { title: 'Admin', robots: { index: false } }

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const loggedIn = await isAdmin()

  return (
    <div className="min-h-screen bg-neutral-50">
      <header className="border-b border-neutral-200 bg-white">
        <div className="mx-auto flex h-16 max-w-5xl items-center justify-between px-4">
          <Link href="/admin" className="flex items-center gap-3">
            <Image src="/logo.jpeg" alt="" width={80} height={44} className="h-10 w-auto" />
            <span className="text-sm tracking-[0.3em]">ADMIN</span>
          </Link>
          <div className="flex items-center gap-5 text-sm">
            <Link href="/" className="underline underline-offset-4">
              View store
            </Link>
            {loggedIn && (
              <form action={logoutAction}>
                <button type="submit" className="underline underline-offset-4">
                  Log out
                </button>
              </form>
            )}
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-5xl px-4 py-8">{children}</main>
    </div>
  )
}
