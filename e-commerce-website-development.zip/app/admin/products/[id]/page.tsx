import { notFound, redirect } from 'next/navigation'
import { ProductForm } from '@/components/admin/product-form'
import { isAdmin } from '@/lib/auth'
import { getProductById } from '@/lib/store'

export default async function EditProductPage({ params }: { params: Promise<{ id: string }> }) {
  if (!(await isAdmin())) redirect('/admin')
  const product = await getProductById((await params).id)
  if (!product) notFound()

  return (
    <div>
      <h1 className="text-2xl uppercase">Edit: {product.name}</h1>
      <ProductForm product={product} />
    </div>
  )
}
