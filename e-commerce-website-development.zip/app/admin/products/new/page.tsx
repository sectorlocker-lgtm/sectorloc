import { redirect } from 'next/navigation'
import { ProductForm } from '@/components/admin/product-form'
import { isAdmin } from '@/lib/auth'

export default async function NewProductPage() {
  if (!(await isAdmin())) redirect('/admin')
  return (
    <div>
      <h1 className="text-2xl uppercase">New post</h1>
      <ProductForm />
    </div>
  )
}
