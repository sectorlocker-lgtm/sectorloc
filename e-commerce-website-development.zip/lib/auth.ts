import { cookies } from 'next/headers'
import { createHmac, timingSafeEqual } from 'crypto'

const COOKIE_NAME = 'sl_admin'

function adminPassword() {
  return process.env.ADMIN_PASSWORD || 'ahp'
}

function sessionToken() {
  return createHmac('sha256', adminPassword()).update('sectorlocker-admin-session').digest('hex')
}

export function verifyPassword(input: string) {
  const a = Buffer.from(input)
  const b = Buffer.from(adminPassword())
  return a.length === b.length && timingSafeEqual(a, b)
}

export async function isAdmin() {
  const value = (await cookies()).get(COOKIE_NAME)?.value
  return value === sessionToken()
}

export async function startAdminSession() {
  ;(await cookies()).set(COOKIE_NAME, sessionToken(), {
    httpOnly: true,
    secure: true,
    sameSite: 'none',
    path: '/',
    maxAge: 60 * 60 * 24 * 7,
  })
}

export async function endAdminSession() {
  ;(await cookies()).delete(COOKIE_NAME)
}
