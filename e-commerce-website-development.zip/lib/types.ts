export const SIZE_OPTIONS = ['X-SMALL', 'SMALL', 'MEDIUM', 'LARGE', 'X-LARGE'] as const

export type Size = {
  label: string
  available: boolean
}

export type Product = {
  id: string
  slug: string
  name: string
  price: number
  compareAtPrice: number | null
  description: string
  images: string[]
  sizes: Size[]
  archived: boolean
  createdAt: string
}

export type Settings = {
  announcement: string
  collectionTitle: string
}

export type OrderItem = {
  productId: string
  name: string
  size: string
  price: number
  quantity: number
}

export type Order = {
  id: string
  name: string
  phone: string
  address: string
  transactionId: string
  items: OrderItem[]
  total: number
  createdAt: string
}

export type Subscriber = {
  email: string
  createdAt: string
}

export function isSoldOut(product: Product) {
  return product.sizes.every((size) => !size.available)
}
