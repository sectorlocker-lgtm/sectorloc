import type { Product, Settings } from './types'

const description =
  'Our signature Forest Thermal in a heavyweight 100% cotton waffle knit. Front chest tree print with the SectorLocker script wordmark and hand-lettered sleeve detailing. Slightly cropped, true to size.'

export const seedProducts: Product[] = [
  {
    id: 'seed-white',
    slug: 'forest-thermal-white',
    name: 'Forest Thermal (White)',
    price: 4400,
    compareAtPrice: 5100,
    description,
    images: ['/products/forest-thermal-white.png', '/material.png'],
    sizes: [
      { label: 'X-SMALL', available: false },
      { label: 'SMALL', available: true },
      { label: 'MEDIUM', available: true },
      { label: 'LARGE', available: true },
      { label: 'X-LARGE', available: false },
    ],
    archived: false,
    createdAt: '2026-10-10T10:00:03.000Z',
  },
  {
    id: 'seed-black',
    slug: 'forest-thermal-black',
    name: 'Forest Thermal (Black)',
    price: 5100,
    compareAtPrice: null,
    description,
    images: ['/products/forest-thermal-black.png', '/material.png'],
    sizes: [
      { label: 'X-SMALL', available: false },
      { label: 'SMALL', available: false },
      { label: 'MEDIUM', available: false },
      { label: 'LARGE', available: false },
      { label: 'X-LARGE', available: false },
    ],
    archived: false,
    createdAt: '2026-10-10T10:00:02.000Z',
  },
  {
    id: 'seed-green',
    slug: 'forest-thermal-green',
    name: 'Forest Thermal (Green)',
    price: 5100,
    compareAtPrice: null,
    description,
    images: ['/products/forest-thermal-green.png', '/material.png'],
    sizes: [
      { label: 'X-SMALL', available: false },
      { label: 'SMALL', available: false },
      { label: 'MEDIUM', available: false },
      { label: 'LARGE', available: false },
      { label: 'X-LARGE', available: false },
    ],
    archived: false,
    createdAt: '2026-10-10T10:00:01.000Z',
  },
]

export const seedSettings: Settings = {
  announcement: 'NEW THERMALS 6/10',
  collectionTitle: 'FOREST THERMALS',
}
