import { promises as fs } from 'fs'
import path from 'path'
import { randomUUID } from 'crypto'
import { sql } from './db'
import { seedProducts, seedSettings } from './seed'
import type { Order, Product, Settings, Subscriber } from './types'

// Vercel serverless functions can only write to /tmp; locally we keep data in the project.
const DATA_DIR = process.env.VERCEL ? '/tmp/sectorlocker' : path.join(process.cwd(), 'data')
export const UPLOAD_DIR = path.join(DATA_DIR, 'uploads')

const FILES = {
  products: path.join(DATA_DIR, 'products.json'),
  settings: path.join(DATA_DIR, 'settings.json'),
  orders: path.join(DATA_DIR, 'orders.json'),
  subscribers: path.join(DATA_DIR, 'subscribers.json'),
}

async function writeJson(file: string, data: unknown) {
  await fs.mkdir(DATA_DIR, { recursive: true })
  await fs.writeFile(file, JSON.stringify(data, null, 2), 'utf8')
}

async function readJson<T>(file: string, fallback: T): Promise<T> {
  try {
    return JSON.parse(await fs.readFile(file, 'utf8')) as T
  } catch {
    await writeJson(file, fallback)
    return fallback
  }
}

function slugify(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
}

export async function getProducts() {
  const products = await readJson<Product[]>(FILES.products, seedProducts)
  return [...products].sort((a, b) => b.createdAt.localeCompare(a.createdAt))
}

export async function getProductBySlug(slug: string) {
  return (await getProducts()).find((p) => p.slug === slug) ?? null
}

export async function getProductById(id: string) {
  return (await getProducts()).find((p) => p.id === id) ?? null
}

export type ProductInput = Omit<Product, 'id' | 'slug' | 'createdAt'> & { id?: string }

export async function upsertProduct(input: ProductInput) {
  const products = await getProducts()
  const existing = input.id ? products.find((p) => p.id === input.id) : undefined

  const baseSlug = slugify(input.name) || 'product'
  let slug = baseSlug
  let n = 2
  while (products.some((p) => p.slug === slug && p.id !== existing?.id)) {
    slug = `${baseSlug}-${n++}`
  }

  const product: Product = {
    ...input,
    id: existing?.id ?? randomUUID(),
    slug,
    createdAt: existing?.createdAt ?? new Date().toISOString(),
  }

  const next = existing
    ? products.map((p) => (p.id === existing.id ? product : p))
    : [product, ...products]
  await writeJson(FILES.products, next)
  return product
}

export async function deleteProduct(id: string) {
  const products = await getProducts()
  await writeJson(
    FILES.products,
    products.filter((p) => p.id !== id),
  )
}

export async function getSettings() {
  return readJson<Settings>(FILES.settings, seedSettings)
}

export async function saveSettings(settings: Settings) {
  await writeJson(FILES.settings, settings)
}

type OrderRow = {
  id: string
  name: string
  phone: string
  address: string
  transaction_id: string
  items: Order['items']
  total: string
  created_at: string | Date
}

export async function getOrders(): Promise<Order[]> {
  const rows = (await sql`
    SELECT id, name, phone, address, transaction_id, items, total, created_at
    FROM orders ORDER BY created_at DESC LIMIT 500
  `) as OrderRow[]
  return rows.map((r) => ({
    id: r.id,
    name: r.name,
    phone: r.phone,
    address: r.address,
    transactionId: r.transaction_id,
    items: r.items,
    total: Number(r.total),
    createdAt: new Date(r.created_at).toISOString(),
  }))
}

export async function addOrder(order: Omit<Order, 'id' | 'createdAt'>) {
  const id = randomUUID().slice(0, 8).toUpperCase()
  await sql`
    INSERT INTO orders (id, name, phone, address, transaction_id, items, total)
    VALUES (${id}, ${order.name}, ${order.phone}, ${order.address}, ${order.transactionId},
            ${JSON.stringify(order.items)}::jsonb, ${order.total})
  `
  return { id }
}

export async function getSubscribers() {
  return readJson<Subscriber[]>(FILES.subscribers, [])
}

export async function addSubscriber(email: string) {
  const subscribers = await getSubscribers()
  if (subscribers.some((s) => s.email === email)) return
  await writeJson(FILES.subscribers, [{ email, createdAt: new Date().toISOString() }, ...subscribers])
}

const ALLOWED_IMAGE_TYPES: Record<string, string> = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
  'image/gif': 'gif',
  'image/avif': 'avif',
}

export const MAX_UPLOAD_BYTES = 8 * 1024 * 1024

export async function saveUpload(file: File) {
  const ext = ALLOWED_IMAGE_TYPES[file.type]
  if (!ext) throw new Error('Only JPG, PNG, WEBP, GIF or AVIF images are allowed.')
  if (file.size > MAX_UPLOAD_BYTES) throw new Error('Each image must be under 8MB.')

  await fs.mkdir(UPLOAD_DIR, { recursive: true })
  const name = `${randomUUID()}.${ext}`
  await fs.writeFile(path.join(UPLOAD_DIR, name), Buffer.from(await file.arrayBuffer()))
  return `/api/uploads/${name}`
}
