export function formatPrice(amount: number, withCurrency = true) {
  const value = amount.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  return withCurrency ? `Tk ${value} BDT` : `Tk ${value}`
}
